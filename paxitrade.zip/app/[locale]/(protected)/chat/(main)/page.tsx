// import dynamic from 'next/dynamic';

export default function ChatPage() {
  //   const ChatSSRSkeleton = dynamic(() => import('@/components/dialogs/skeleton'), {
  //     ssr: true,
  //   });
  return <div>{/* <ChatSSRSkeleton/> */}</div>;
}
