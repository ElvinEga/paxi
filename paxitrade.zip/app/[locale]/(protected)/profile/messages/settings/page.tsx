import React from 'react';

const SettingPageChat = () => {
  return (
    <div>
      <h1>settings</h1>
      {/* Add your followers list or relevant content here */}
    </div>
  );
};

export default SettingPageChat;
