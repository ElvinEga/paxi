import React from 'react';

const FollowersPage = () => {
  return (
    <div>
      {/* <h1>Followers</h1> */}
      <div className='my-2 '>
        {/* <input className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 pl-8 pr-4 dark:bg-input" placeholder="Search by name" type="text" value=""></input> */}
      </div>
      <div className='my-2 px-0'>No info yet</div>
    </div>
  );
};

export default FollowersPage;
