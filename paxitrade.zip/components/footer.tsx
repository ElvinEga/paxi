import ClientFooter from './footer.client';

export function SiteFooter() {
  return <ClientFooter />;
}
