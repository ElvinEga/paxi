Most of the parts of this section had been copied from: https://github.com/Volcomix/virtual-background

LICENSE: Apache License 2.0
https://github.com/Volcomix/virtual-background/blob/main/LICENSE