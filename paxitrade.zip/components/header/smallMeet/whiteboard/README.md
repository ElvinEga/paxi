Some parts of this section had been copied from: https://github.com/excalidraw/excalidraw/blob/master/src/excalidraw-app

LICENSE: MIT License

Copyright (c) 2020 Excalidraw
