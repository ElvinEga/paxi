import { TFLite } from '../virtual-background/hooks/useTFLite';
declare function createTFLiteSIMDModule(): Promise<TFLite>;
export default createTFLiteSIMDModule;
