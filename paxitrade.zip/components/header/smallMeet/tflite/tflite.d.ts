import { TFLite } from '@/components/meet/virtual-background/hooks/useTFLite';
declare function createTFLiteModule(): Promise<TFLite>;
export default createTFLiteModule;
